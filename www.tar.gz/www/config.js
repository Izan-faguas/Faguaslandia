const CONFIG = {
  API_BASE_URL: "http://192.168.1.159:8081"
};

export default CONFIG;